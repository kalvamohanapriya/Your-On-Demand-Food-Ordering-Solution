const express = require("express");
const router = express.Router();
const Food = require("../models/Food");

// ✅ GET all foods
router.get("/", async (req, res) => {
  try {
    const foods = await Food.find();
    res.json(foods);
  } catch (error) {
    res.status(500).json({ message: "Error fetching foods" });
  }
});

// ✅ GET food by ID
router.get("/:id", async (req, res) => {
  try {
    const food = await Food.findById(req.params.id);
    if (!food) {
      return res.status(404).json({ message: "Food not found" });
    }
    res.json(food);
  } catch (error) {
    res.status(500).json({ message: "Invalid ID" });
  }
});

// ✅ POST add food
router.post("/add", async (req, res) => {
  try {
    const newFood = new Food({
      name: req.body.name,
      price: req.body.price,
    });
    await newFood.save();
    res.json({ message: "Food Added Successfully ✅" });
  } catch (error) {
    res.status(500).json({ message: "Error adding food" });
  }
});

// ✅ UPDATE food by ID
router.put("/:id", async (req, res) => {
  try {
    const updatedFood = await Food.findByIdAndUpdate(
      req.params.id,
      {
        name: req.body.name,
        price: req.body.price,
      },
      { new: true }
    );
    res.json(updatedFood);
  } catch (error) {
    res.status(500).json({ message: "Error updating food" });
  }
});

// ✅ DELETE food by ID
router.delete("/:id", async (req, res) => {
  try {
    await Food.findByIdAndDelete(req.params.id);
    res.json({ message: "Food deleted successfully ❌" });
  } catch (error) {
    res.status(500).json({ message: "Error deleting food" });
  }
});

module.exports = router;