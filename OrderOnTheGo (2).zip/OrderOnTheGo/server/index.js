const express = require("express");
const mongoose = require("mongoose");
const cors = require("cors");

const app = express();
app.use(cors());
app.use(express.json());

const foodSchema = new mongoose.Schema({
  name: String,
  price: Number,
  category: String
});

// Schema
const Food = mongoose.model("Food", {
  name: String,
  price: Number
});

// Add sample food (only first time)
app.get("/add", async (req, res) => {
  await Food.create({ name: "Burger", price: 120 });
  res.send("Food Added");
});

// Get all foods
app.get("/api/foods", async (req, res) => {
  const foods = await Food.find();
  res.json(foods);
});

app.listen(5000, () => {
  console.log("Server running on port 5000");

app.get("/addfoods", async (req, res) => {
  await Food.deleteMany({});

  await Food.insertMany([
    { name: "Burger", price: 120, category: "Burgers" },
    { name: "Cheese Burger", price: 150, category: "Burgers" },

    { name: "French Fries", price: 80, category: "Fries" },
    { name: "Peri Peri Fries", price: 100, category: "Fries" },

    { name: "Mango Juice", price: 70, category: "Juices" },
    { name: "Orange Juice", price: 60, category: "Juices" },

    { name: "Chocolate Cake", price: 140, category: "Desserts" },
    { name: "Ice Cream", price: 90, category: "Desserts" }
  ]);

  res.send("Foods Added Successfully");
});