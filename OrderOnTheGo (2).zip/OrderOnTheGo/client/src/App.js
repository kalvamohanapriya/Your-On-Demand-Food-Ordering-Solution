import React, { useEffect, useState } from "react";

function App() {
  const [foods, setFoods] = useState([]);
  const [cart, setCart] = useState([]);

  useEffect(() => {
    fetch("http://localhost:5000/api/foods")
      .then(res => res.json())
      .then(data => setFoods(data));
  }, []);

  const addToCart = (food) => {
    setCart([...cart, food]);
  };

  const total = cart.reduce((sum, item) => sum + item.price, 0);

  return (
    <div style={{ textAlign: "center", marginTop: "40px" }}>
      <h1>🍔 Order On The Go</h1>

      <h2>Food Menu</h2>
      {foods.map((food) => (
        <div key={food._id} style={{ margin: "10px" }}>
          {food.name} - ₹{food.price}
          <button 
            onClick={() => addToCart(food)} 
            style={{ marginLeft: "10px" }}
          >
            Add
          </button>
        </div>
      ))}

      <h2 style={{ marginTop: "30px" }}>🛒 Cart</h2>
      {cart.length === 0 ? (
        <p>No items selected</p>
      ) : (
        cart.map((item, index) => (
          <div key={index}>
            {item.name} - ₹{item.price}
          </div>
        ))
      )}

      <h3 style={{ marginTop: "20px" }}>
        Total Cost: ₹{total}
      </h3>
    </div>
  );
}

export default App;